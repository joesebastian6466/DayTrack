# DayTrack V5 — phone/cloud build

This version is prepared for a phone-only workflow. You do NOT need a PC to compile it.

## What is included
- Custom activities
- Categories
- Custom repeat days
- Reminder time saved with each activity
- Daily completion ring
- Previous/next day
- Offline local storage
- Light/dark theme follows Android system setting
- Long-press an activity to edit/delete
- GitHub Actions workflow that builds an Android release APK in the cloud

## Build from your Android phone
1. Create/sign in to a GitHub account.
2. Create a new repository, e.g. `daytrack`.
3. Upload the contents of this folder, including `.github/workflows/build-apk.yml`.
4. Open the repository's **Actions** tab.
5. Open **Build DayTrack APK** and wait for the workflow to finish.
6. Open the successful workflow run.
7. Under **Artifacts**, tap **DayTrack-APK** to download the APK.
8. Open the downloaded APK and allow your browser/file manager to install apps if Android asks.

The workflow uses GitHub Actions to generate the standard Android project files, compile the Flutter app, and upload the resulting APK as a workflow artifact.

Note: V5 stores reminder times but does not yet schedule background notifications. That will be added in a later version.
