import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const DayTrackApp());
}

class Activity {
  Activity({
    required this.id,
    required this.name,
    required this.category,
    required this.icon,
    required this.days,
    this.reminder,
    this.done = false,
  });

  final String id;
  String name;
  String category;
  String icon;
  List<int> days; // 1=Mon ... 7=Sun
  TimeOfDay? reminder;
  bool done;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'category': category,
        'icon': icon,
        'days': days,
        'reminder': reminder == null
            ? null
            : {'hour': reminder!.hour, 'minute': reminder!.minute},
        'done': done,
      };

  factory Activity.fromJson(Map<String, dynamic> j) {
    final r = j['reminder'];
    return Activity(
      id: j['id'] as String,
      name: j['name'] as String,
      category: j['category'] as String? ?? 'General',
      icon: j['icon'] as String? ?? 'check',
      days: List<int>.from(j['days'] ?? const [1, 2, 3, 4, 5, 6, 7]),
      reminder: r == null
          ? null
          : TimeOfDay(hour: r['hour'] as int, minute: r['minute'] as int),
      done: j['done'] as bool? ?? false,
    );
  }
}

class DayTrackApp extends StatelessWidget {
  const DayTrackApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'DayTrack',
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.dark,
      ),
      themeMode: ThemeMode.system,
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<Activity> _activities = [];
  DateTime _date = DateTime.now();
  bool _loading = true;

  String get _dateKey =>
      '${_date.year}-${_date.month.toString().padLeft(2, '0')}-${_date.day.toString().padLeft(2, '0')}';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('activities');
    final savedDate = prefs.getString('activeDate');
    if (raw != null) {
      final list = (jsonDecode(raw) as List)
          .map((e) => Activity.fromJson(Map<String, dynamic>.from(e)))
          .toList();
      _activities.addAll(list);
    }
    if (savedDate != null) {
      final p = savedDate.split('-').map(int.parse).toList();
      if (p.length == 3) _date = DateTime(p[0], p[1], p[2]);
    }
    setState(() => _loading = false);
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'activities',
      jsonEncode(_activities.map((e) => e.toJson()).toList()),
    );
    await prefs.setString('activeDate', _dateKey);
  }

  int get _activeWeekday => _date.weekday;

  List<Activity> get _todayActivities =>
      _activities.where((a) => a.days.contains(_activeWeekday)).toList();

  int get _done => _todayActivities.where((a) => a.done).length;

  Future<void> _addOrEdit([Activity? old]) async {
    final name = TextEditingController(text: old?.name ?? '');
    final category = TextEditingController(text: old?.category ?? 'General');
    String icon = old?.icon ?? 'check';
    List<int> days =
        List<int>.from(old?.days ?? const [1, 2, 3, 4, 5, 6, 7]);
    TimeOfDay? reminder = old?.reminder;

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(old == null ? 'Add activity' : 'Edit activity'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: name,
                  decoration: const InputDecoration(labelText: 'Activity name'),
                ),
                TextField(
                  controller: category,
                  decoration: const InputDecoration(labelText: 'Category'),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: icon,
                  decoration: const InputDecoration(labelText: 'Icon'),
                  items: const [
                    DropdownMenuItem(value: 'check', child: Text('✓ Check')),
                    DropdownMenuItem(value: 'fitness', child: Text('🏋️ Fitness')),
                    DropdownMenuItem(value: 'book', child: Text('📚 Study')),
                    DropdownMenuItem(value: 'water', child: Text('💧 Water')),
                    DropdownMenuItem(value: 'work', child: Text('💼 Work')),
                    DropdownMenuItem(value: 'sleep', child: Text('😴 Sleep')),
                  ],
                  onChanged: (v) => setDialogState(() => icon = v ?? 'check'),
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Repeat on'),
                ),
                Wrap(
                  spacing: 4,
                  children: List.generate(7, (i) {
                    final day = i + 1;
                    return FilterChip(
                      label: Text(['M','T','W','T','F','S','S'][i]),
                      selected: days.contains(day),
                      onSelected: (selected) {
                        setDialogState(() {
                          if (selected) {
                            days.add(day);
                          } else {
                            days.remove(day);
                          }
                        });
                      },
                    );
                  }),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(reminder == null
                      ? 'No reminder'
                      : 'Reminder: ${reminder!.format(context)}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.alarm),
                    onPressed: () async {
                      final picked = await showTimePicker(
                        context: context,
                        initialTime: reminder ?? TimeOfDay.now(),
                      );
                      if (picked != null) {
                        setDialogState(() => reminder = picked);
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
          actions: [
            if (old != null)
              TextButton(
                onPressed: () {
                  _activities.removeWhere((a) => a.id == old.id);
                  Navigator.pop(context, true);
                },
                child: const Text('Delete'),
              ),
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                if (name.text.trim().isEmpty || days.isEmpty) return;
                if (old == null) {
                  _activities.add(Activity(
                    id: DateTime.now().microsecondsSinceEpoch.toString(),
                    name: name.text.trim(),
                    category: category.text.trim().isEmpty
                        ? 'General'
                        : category.text.trim(),
                    icon: icon,
                    days: List<int>.from(days),
                    reminder: reminder,
                  ));
                } else {
                  old.name = name.text.trim();
                  old.category = category.text.trim().isEmpty
                      ? 'General'
                      : category.text.trim();
                  old.icon = icon;
                  old.days = List<int>.from(days);
                  old.reminder = reminder;
                }
                Navigator.pop(context, true);
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );

    if (result == true) {
      setState(() {});
      await _save();
    }
  }

  void _moveDay(int amount) async {
    setState(() => _date = _date.add(Duration(days: amount)));
    for (final a in _activities) {
      a.done = false;
    }
    await _save();
  }

  void _toggle(Activity a) async {
    setState(() => a.done = !a.done);
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final today = _todayActivities;
    final progress = today.isEmpty ? 0.0 : _done / today.length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('DayTrack'),
        actions: [
          IconButton(
            tooltip: 'Add activity',
            onPressed: _addOrEdit,
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _save,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Row(
              children: [
                IconButton(
                  onPressed: () => _moveDay(-1),
                  icon: const Icon(Icons.chevron_left),
                ),
                Expanded(
                  child: Column(
                    children: [
                      Text(
                        '${_date.day}/${_date.month}/${_date.year}',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      Text(
                        _date.weekday == DateTime.now().weekday &&
                                _date.day == DateTime.now().day &&
                                _date.month == DateTime.now().month &&
                                _date.year == DateTime.now().year
                            ? 'Today'
                            : ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][_activeWeekday - 1],
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => _moveDay(1),
                  icon: const Icon(Icons.chevron_right),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Row(
                  children: [
                    SizedBox(
                      width: 90,
                      height: 90,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          CircularProgressIndicator(
                            value: progress,
                            strokeWidth: 9,
                          ),
                          Text('${(_done / (today.isEmpty ? 1 : today.length) * 100).round()}%'),
                        ],
                      ),
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Daily progress',
                              style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 6),
                          Text('$_done of ${today.length} activities completed'),
                          const SizedBox(height: 6),
                          Text(
                            today.isEmpty
                                ? 'Add your first activity.'
                                : progress == 1
                                    ? 'Goal complete 🎉'
                                    : 'Keep going!',
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            if (today.isEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      const Icon(Icons.event_note, size: 48),
                      const SizedBox(height: 10),
                      const Text('No activities for this day.'),
                      const SizedBox(height: 12),
                      FilledButton.icon(
                        onPressed: _addOrEdit,
                        icon: const Icon(Icons.add),
                        label: const Text('Add activity'),
                      ),
                    ],
                  ),
                ),
              )
            else
              ...today.map(
                (a) => Card(
                  child: ListTile(
                    leading: Text(
                      a.icon == 'fitness'
                          ? '🏋️'
                          : a.icon == 'book'
                              ? '📚'
                              : a.icon == 'water'
                                  ? '💧'
                                  : a.icon == 'work'
                                      ? '💼'
                                      : a.icon == 'sleep'
                                          ? '😴'
                                          : '✓',
                      style: const TextStyle(fontSize: 24),
                    ),
                    title: Text(
                      a.name,
                      style: TextStyle(
                        decoration:
                            a.done ? TextDecoration.lineThrough : null,
                      ),
                    ),
                    subtitle: Text(
                      a.reminder == null
                          ? a.category
                          : '${a.category} • ${a.reminder!.format(context)}',
                    ),
                    leadingAndTrailingPadding: 8,
                    trailing: Checkbox(
                      value: a.done,
                      onChanged: (_) => _toggle(a),
                    ),
                    onLongPress: () => _addOrEdit(a),
                  ),
                ),
              ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _addOrEdit,
              icon: const Icon(Icons.add),
              label: const Text('Customize activities'),
            ),
            const SizedBox(height: 20),
            Text(
              'Tip: long-press an activity to edit or delete it.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}
